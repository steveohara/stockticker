                  
	    tkdnd: Tk Drag & Drop extension
		     (Version 1.0.0)

This directory holds a collection of files that add native drag & drop
capabilities to the tk toolkit. It is designed for tk versions >= 8.3.3,
but with simple modifications can be applied to any tk version greater than
8.1.

Remember that this software is in development. Please report any bugs or
feature requests directly to the author (petasis@iit.demokritos.gr) or by
posting on the comp.lang.tcl newsgroup. In the latter case, please use
"tkdnd" in the title of the posting.

This software (tkdnd) is copyrighted by:
    George Petasis, National Centre for Scientific Research "Demokritos",
    Aghia Paraskevi, Athens, Greece.
    e-mail: petasis@iit.demokritos.gr
                 and
    Laurent Riesterer, Rennes, France.
    e-mail: (laurent.riesterer@free.fr)

and is under the same license that covers tcl. Free to use for anything :-)

For any questions and suggestions contact me at

  petasis@iit.demokritos.gr

or post a question at comp.lang.tcl (preferable)
